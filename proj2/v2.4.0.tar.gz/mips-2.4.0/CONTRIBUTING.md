# Contributing

## Submitting a Pull Request

1. Fork it.
2. Create a branch (`git checkout -b my_project`)
3. Commit your changes (`git commit -a`) [Tips for better commit message](https://robots.thoughtbot.com/5-useful-tips-for-a-better-commit-message)
4. Push to the branch (`git push origin my_project`)
5. Open a [Pull Request][1]
6. Enjoy a refreshing Diet Coke and wait doing more

[1]: https://github.com/ArchC/mips/pulls
